app.filter('nameFilter', function(){
  return function(item){
     return item.split('.').pop();
  }
});

app.filter('_propFilter', function(){
  return function(item){
    var obj = {};
    for(var prop in item){
      if(prop.indexOf('_')===0){
        obj[prop] = item[prop]
      }
    }
    return obj;
  }
});