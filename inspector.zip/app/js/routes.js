app.config(function($stateProvider, $urlRouterProvider) {
  //
  // For any unmatched url, redirect to /state1
  $urlRouterProvider.otherwise("/");
  //
  // Now set up the states
  $stateProvider
    .state('home',{
      url: '/',
      templateUrl : './templates/home.html'
    })
    // .state('inspect',{
    //   url: '/inspect',
    //   templateUrl: './templates/partials/inspect.html'
    // })
    .state('inspect',{
      url: '/inspect',      
      views: {
        '' : {
          templateUrl: './templates/partials/inspect.html'    
        },
        'image@inspect': {
          templateUrl: './templates/partials/image.html',
          controller: 'imageController'
        },
        'node@inspect': {
          templateUrl: './templates/partials/node.html',
          controller: 'nodeController'
        },
        'properties@inspect': {
          templateUrl: './templates/partials/properties.html',
          controller: 'propertiesController'
        }
      }
    });

});