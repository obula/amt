app.controller('propertiesController', function($scope, $rootScope, appData){  
  
  $scope.selectedNode = appData.getSelectedNode();

  $rootScope.$on('nodechanged', function($event, node){
		$scope.selectedNode = node;
	});


});
