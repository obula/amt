app.controller('MainController', function($scope, WebServices, appData){

	WebServices.getXMLData('data/data.xml').then(function(xmlData){
		//converting xml data to json data
		var jsonData = new X2JS().xml_str2json(xmlData);

		// var transformedData = {};
		//parsing jsondata to covert object to array
		transformData(jsonData.hierarchy, 'node');

		appData.setData(jsonData.hierarchy);


	});

	var nodeId = 0;
	function transformData(d, prop){
		var currentNode = d[prop];
		if(d && !d.name && d._class){
			d.PROPS = {};
			d.PROPS.NAME = d._class.split('.').pop();
			d.PROPS.STATE='collapse';
			d.PROPS.ID = ++nodeId;
			d.PROPS.BOUNDS =  d._bounds.match(/\d+/g);
		}
		if(currentNode instanceof Array){
			for(var i=0; i<currentNode.length; i++){
				transformData(currentNode[i], prop)
			}
		}else if(currentNode){
			d[prop] = [currentNode];
			transformData(currentNode, prop)
		}
	}

})