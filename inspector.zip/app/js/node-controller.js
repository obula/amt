app.controller('nodeController', function($scope, $rootScope, $timeout,  appData){
  $scope.data = appData.getData();
  $scope.selectedNode =  $scope.data.node[0];	

	$scope.onNodeClick = function(node){
		if(node.node && node.node.length){
			node.PROPS.STATE = (node.PROPS.STATE ==='expand') ? 'collapse' : 'expand';	
		}
		$scope.selectedNode = node;

		$scope.$emit('nodechanged', $scope.selectedNode);
	};

	$timeout(function(){
		$scope.onNodeClick($scope.selectedNode);
	}, 100);

	$rootScope.$on('image:nodechanged', function($event, node){
		console.log('image:nodechanged');
		console.log(node);
		
		$timeout(function(){
			$scope.onNodeClick(node);
		}, 100);

	});

});
