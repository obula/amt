app.service('WebServices', function($http, $q){

	this.getXMLData = function(url){
		var deferred = $q.defer();
		var config = {
      "method": 'get',
      "url": url
    };

		$http(config).success(function(data, status, headers, config) {
			deferred.resolve(data)
		}).error(function(data, status, headers, config){
			deferred.reject(data);
		});

		return deferred.promise;
	}

})