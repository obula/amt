app.controller('imageController', function($scope, $rootScope, appData){
  $scope.data = appData.getData();
  $scope.selectedNode = {};

	//create a DOM (div) node for each node from the document
  var fragNode = document.createDocumentFragment();
  function getDiv(node){
		var bounds = node.PROPS.BOUNDS;
		var div = $('<div>');
		div.addClass('box');
		div.attr('id', node.PROPS.ID)
		var w = bounds[2] - bounds[0];
		var h = bounds[3] - bounds[1];
		div.width(w);
		div.height(h);
		div.css('left', bounds[0]+'px');
		div.css('top', bounds[1]+'px');		
		div.attr('bounds', bounds);

		fragNode.appendChild(div.get(0));
	}

	function transformData(d, prop){
		var nodes = d[prop] || [];
		for(var i=0; i<nodes.length; i++){
			getDiv( nodes[i] );
			transformData( nodes[i], prop)
		}
	}

	function ImageTransition(){
		var AIW = 1080;
		var AIH = 1920;
		var CW = 350;
		var CH = 700;

		var leftContainer = $('div.container.left');


		var container = $('div.image-container');
		var img = container.find('.image');
		var parentContainer = container.parent();//$('div.container.left');
		CW = parentContainer.width();
		CH = parentContainer.height();

		var hdiff = container.offset().top - leftContainer.offset().top;
		CH = CH - hdiff - 20;

		console.log(leftContainer.offset().top, container.offset().top, hdiff)
		// return;
		container.width(CW);
		container.height(CH);

		var rw = CW / AIW;
		var rh = CH / AIH;
		var r = (rw < rh) ? rw : rh;
	// --------------------------------------------------------------
		var scale = r;//0.36;
		console.log(scale);
		img.width(AIW);
		img.height(AIH);

		var tx=0, ty=0;
		var tx = (AIW*scale - CW);
		tx = 1/scale * tx * -0.5;

		var ty = (AIH*scale - CH);
		ty = 1/scale * ty * 0.5;

		transform(img, scale, tx, -ty);
	}

	function transform(node, scale, tx, ty){
		node.css( 'transform', 'scale('+ scale +') translate(' + tx + 'px, ' + ty + 'px)'  );
	}

	$rootScope.$on('layoutResize', function(){
		ImageTransition();
	});
	
	transformData($scope.data, 'node');
	var imageNode = $('.image');
	
	imageNode.bind('mouseover', function(evt){
		var node = $(evt.target);
		setFocus(node);
	});

	imageNode.bind('mouseout', function(evt){
		var node = evt.target;
		$(node).removeClass('active');
	});

	imageNode.bind('click', function(evt){
		var node = $(evt.target);
		setFocus(node);

		getNodeById($scope.data, 'node', node.attr('id'));

		$scope.$broadcast('image:nodechanged', $scope.selectedNode);
		$scope.$emit('image:nodechanged', $scope.selectedNode);

	});


	ImageTransition();
	imageNode.get(0).appendChild(fragNode);

	$rootScope.$on('nodechanged', function($event, node){
		$scope.selectedNode = node;		
		var node = $('#'+$scope.selectedNode.PROPS.ID);
		setFocus(node);
	});

	var boxes = $('.box');
	function setFocus(node){
		boxes.removeClass('active');
		node.addClass('active');
	}

	function getNodeById(data, prop, id){
		
		var nodes = data[prop] || [];
		for(var i=0; i<nodes.length; i++){
			if(nodes[i].PROPS.ID == id){
				console.log(" found ");
				$scope.selectedNode = nodes[i];
			}else{
				getNodeById( nodes[i], prop, id);	
			}			
		}
	}


});
