app.service('appData', function(){
	var _data = null;
	var _selectedNode = null;

	this.setData = function(data){
		_data = data;
	};

	this.getData = function(){
		return _data;
	};

	this.setSelectedNode = function(node){
		_selectedNode = node;
	};

	this.getSelectedNode = function(){
		return _selectedNode;
	};

})