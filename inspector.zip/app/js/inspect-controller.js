app.controller('MainController', function($scope, appData){

	$scope.data = appData.getData();
  $scope.selectedNode = {};


})