var app = angular.module("myLayout", []);
app.directive("layout", function($compile){

	return {
		restrict  : "E",
		templateUrl : 'components/layout/layout.html',
		scope : {
			config : '=config',
			leftContent : '@',
			rightTopContent : '@',
			rightBottomContent : '@'
		},
		link : function(scope, element, attrs, controller){

			var elem = $(element);
			var lcontainer = elem.find('.layout-container')
			var deviders = elem.find('.devider');
			var dThickness = elem.find('.devider.vertical').width();
			var leftContainer = elem.find('.container.left');
			var rightContainer = elem.find('.container.right');
			var topContainer = elem.find('.container.top');
			var bottomContainer = elem.find('.container.bottom');

			leftContainer.html(attrs.leftContent || '');
			topContainer.html(attrs.rightTopContent || '');
			bottomContainer.html(attrs.rightBottomContent || '');

			console.log('attrs.leftContent');
			console.log(attrs.leftContent);

			var leftContainerMinWidth = 400;
			var rightContainerMinWidth = 400;
			var topContainerMinHeight = 300;
			var bottomContainerMinHeight = 300;

			var leftContainerMinWidthInPercent,
					rightContainerMinWidthInPercent,
					topContainerMinHeightInPercent,
					bottomContainerMinHeightInPercent;

			lw = lcontainer.width();
			lh = lcontainer.height();

			leftContainerMinWidthInPercent = leftContainerMinWidth / lw * 100;
			rightContainerMinWidthInPercent = rightContainerMinWidth / lw * 100;
			topContainerMinHeightInPercent = topContainerMinHeight / lh * 100;
			bottomContainerMinHeightInPercent = bottomContainerMinHeight / lh * 100;

			console.log(dThickness, lw, lh);

			var containerPos = lcontainer.offset();
			containerPos.x = containerPos.left;
			containerPos.y = containerPos.top;

			var downPos = {x:0, y:0};
			var diffPos = {x:0, y:0};
			var currentDevider = null;

			function onDragStart(event){
				currentDevider = $(event.currentTarget);
				downPos.x = event.clientX;
				downPos.y = event.clientY;

				$(document).bind('mousemove', onDrag);
				$(document).bind('mouseup', onDragEnd)
			}

			function onDragEnd(event){
				$(document).unbind('mousemove', onDrag);
				$(document).unbind('mouseup', onDragEnd);
			}

			function onDrag(event){
				// diffPos.x = (event.clientX - downPos.x);
				// diffPos.y = (event.clientY - downPos.y);
				diffPos.x = (event.clientX - containerPos.x);
				diffPos.y = (event.clientY - containerPos.y );

				var w = diffPos.x/lw * 100;
				var h = diffPos.y/lh * 100;

				if(currentDevider.hasClass('vertical')){
					if(w < leftContainerMinWidthInPercent){
						w = leftContainerMinWidthInPercent;
					}else if( (100-w) < rightContainerMinWidthInPercent){
						w = 100 - rightContainerMinWidthInPercent;
					}
					currentDevider.css('left', (w+'%'));
					leftContainer.css('width', (w+'%'));
					rightContainer.css('width', ((100-w)+'%'));	

					scope.$broadcast('layoutResize');
					scope.$emit('layoutResize');

				}else{
					if(h < topContainerMinHeightInPercent){
						h = topContainerMinHeightInPercent;
					}else if( (100-h) < bottomContainerMinHeightInPercent){
						h = 100 - bottomContainerMinHeightInPercent;
					}
					currentDevider.css('top', (h+'%'));
					topContainer.css('height', (h+'%'));
					bottomContainer.css('height', ((100-h)+'%'));
				}
			}

			deviders.bind('mousedown', onDragStart);

			$compile(element.contents())(scope);
			
		}

	}
});

